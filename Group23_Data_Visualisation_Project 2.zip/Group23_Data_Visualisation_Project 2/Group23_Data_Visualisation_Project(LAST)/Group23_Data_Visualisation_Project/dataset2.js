

function navigateTo(url) {
    // Navigate to the specified URL
    window.location.href = url;
}

